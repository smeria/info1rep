class Password:
    def __init__(self, name, username, password):
        self._name = name
        self._username = username
        self._password = password

        def pretty_str_password(self):
            return "%s: %s /%s" %(self._name, self._username, self._password)

        def __str__(self):
            return "%s: %s/" %(self._name,self._username)+ len(self._password)*"*"

class PasswordManager:
    def __init__(self,master_password):
        self._master_password = master_password
        self._passwords = {}
        self.unlocked = False

    def lock():
        self.unlocked = False

    def unlock(master_password):
        if master_password == self._master_password:
            self.unlocked = True
            return self.unlocked

    def create_new_password(name, username, password):
        if self.unlocked == True:
            if name not in __password:
                __password[name]== password
                return password
            else:
                return None
        else:
            return None

    def update_password(name, username, password):
        if self.unlocked == True:
            if __password[name] == name:
                __password[password] = password
                __password[username] = username
                return password
            else:
                return None
        else:
            return None

    def get_password(name):
        if self.unlocked == True:
            if __password[name]==name:
                return __password[name]
            else:
                return None
        else:
            return None

    def list_passwords():
        list = []
        if self.unlocked == True:
            for name in __password[name]:
                list.append(pretty_str_password(__password[name]))
                return list
        else:
            for name in __password[name]:
                list.append(__str__(__password[name]))
                return list











