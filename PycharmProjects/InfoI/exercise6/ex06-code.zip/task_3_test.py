from unittest import TestCase

import task_3


class Task3Test(TestCase):
    """
    Task 3: Accounts
    """
