from unittest import TestCase

import task_1


class Task1Test(TestCase):
    """
    Task 1: Quicksort
    """
