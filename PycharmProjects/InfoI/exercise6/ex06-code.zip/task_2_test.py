from unittest import TestCase

import task_2


class Task2Test(TestCase):
    """
    Task 2: List duplicates
    """
