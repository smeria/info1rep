from unittest import TestCase

import task_4


class Task4Test(TestCase):
    """
    Task 4: Swap case
    """
